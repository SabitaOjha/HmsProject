﻿using Microsoft.EntityFrameworkCore;
using Hms.Model;

namespace Hms.Data
{
    public class ApplicationDbContext : DbContext
        
    {

        public DbSet<Doctor> Doctors { get; set; }
        public DbSet<Patient> Patients { get; set; }
        public DbSet<Problems> Problems { get; set; }
        public DbSet<Medicine> Medicines { get; set; }
        public DbSet<UserCredential> UserCredentials { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }
        public ApplicationDbContext()
        {

        }
        
       // protected override void OnModelCreating(ModelBuilder modelBuilder)
      //  {
       //    base.OnModelCreating(modelBuilder);
         //   modelBuilder.Entity<Doctor>().ToTable("tblDoctor");
        //   modelBuilder.Entity<Patient>().ToTable("tblPatient");
       // }
    }
}
