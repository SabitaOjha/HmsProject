﻿using Hms.Data;
using Hms.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Hms.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MedicineController : ControllerBase
    {
        public ApplicationDbContext db;
        public MedicineController(ApplicationDbContext _db)
        {
            this.db = _db;
        }
        [Authorize]
        // GET: api/<MedicineController>
        [HttpGet]
        public IEnumerable<Medicine> Get()
        {
            var result = db.Medicines.ToList();
            return (IEnumerable<Medicine>)result;
        }

        // GET api/<MedicineController>/5
        [HttpGet("{id}")]
        public Medicine Get(int id)
        {
            var result = db.Medicines.Where(a => a.ProblemId == id).FirstOrDefault();
            return result;
        }

        // POST api/<MedicineController>
        [HttpPost ("{id}")]
        public IActionResult Post([FromBody] Medicine medicine, int id)
        {
            Medicine m = new Medicine();
            m.MedicineName = medicine.MedicineName;
            m.Doases = medicine.Doases;
            m.DoaseDescription = medicine.DoaseDescription;
            m.Quantity = medicine.Quantity;
            m.ProblemId = id;
            db.Add(m);
            db.SaveChanges();
            return Ok(m);
        }

        // PUT api/<MedicineController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<MedicineController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
