﻿using Hms.Data;
using Hms.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Hms.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DoctorController : ControllerBase
    {
        public ApplicationDbContext db;
        public DoctorController(ApplicationDbContext _db)
        {
            this.db = _db;
        }
        [Authorize]
        // GET: api/<DoctorController>
       [HttpGet]
        public IEnumerable<Doctor> Get()
        {
            var result = db.Doctors.Where(a=>a.IsActive==true).Include(a => a.Patients).ToList();
            return (IEnumerable<Doctor>)result;

        }

        // GET api/<DoctorController>/5
        //[Route("GetById")]
        [HttpGet("{id}")]
        public Doctor Get(int id)
        {
         var result = db.Doctors.Where(a=> a.Id == id && a.IsActive==true).Include(a=>a.Patients). FirstOrDefault();
 
            return result;
        }

        // POST api/<DoctorController>
        [Route("PostDoctor")]
        [HttpPost]
        public IActionResult PostDoctor([FromBody] Doctor doctor)
        {
            //db.Add(manager);
            //db.SaveChanges();
            Doctor doc1 = new Doctor();
            doc1.FirstName = doctor.FirstName;
            doc1.LastName = doctor.LastName;
            doc1.Address = doctor.Address;
            doc1.Specialization = doctor.Specialization;
            doc1.PhoneNumber = doctor.PhoneNumber;
            db.Add(doc1);
            db.SaveChanges();
            return Ok();

        }

        // PUT api/<DoctorController>/5
        [HttpPut("{id}")]
        public IActionResult UpdateDoctor(int id, [FromBody] Doctor doctor)
        {
            var result = db.Doctors.Where(a=>a.Id==id).FirstOrDefault();
            if (result != null)
            {
                result.FirstName = doctor.FirstName;
                result.LastName = doctor.LastName;
                result.Address = doctor.Address;
                result.Specialization = doctor.Specialization;
                result.PhoneNumber = doctor.PhoneNumber;
                db.SaveChanges();
                return Ok(doctor);
            }
            return null;
        }

        // DELETE api/<DoctorController>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var result = db.Doctors.Where(a => a.Id == id).FirstOrDefault();
            result.IsActive = false;
            db.SaveChanges();
            return Ok(result);
        }
    }
}
