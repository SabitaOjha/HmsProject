﻿using Hms.Data;
using Hms.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Hms.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProblemsController : ControllerBase
    {
        public ApplicationDbContext db;
        public ProblemsController(ApplicationDbContext _db)
        {
            this.db = _db;
        }
        [Authorize]
        // GET: api/<ProblemsController>
        [HttpGet]
        public IEnumerable<Problems> Get()
        {
            var result = db.Problems.Include(a => a.Medicines).ToList();
            return (IEnumerable<Problems>)result;
        }

        // GET api/<ProblemsController>/5
        [Route("GetProblems")]
        [HttpGet("{id}")]
        /*public Problems GetProblems(int id)
        {
            var result = db.Problems.Where(a => a.PatientId == id).Include(a => a.Medicines).FirstOrDefault();
            return result;
        }*/
        [Route("GetProblems")]
        [HttpGet("{id}")]
        public IEnumerable <Problems> Get(int id) 
        {
            var result = db.Problems.Where(a => a.PatientId == id || a.Id == id).Include(a => a.Medicines).ToList();
            return (IEnumerable<Problems>)result;
        }


        // POST api/<ProblemsController>
        [HttpPost("{id}")]
        public IActionResult PostProblems([FromBody] Problems problems, int id)
        {
            Problems pro = new Problems();
            pro.Problem = problems.Problem;
            pro.PatientId = id;
            db.Add(pro);
            db.SaveChanges();
            return Ok(pro);
        }

        // PUT api/<ProblemsController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<ProblemsController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
