﻿using Hms.Data;
using Hms.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;



// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Hms.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientController : ControllerBase
    {
        public ApplicationDbContext db;
        public PatientController(ApplicationDbContext _db)
        {
            this.db = _db;     
        }
        // GET: api/<PatientController>
        [HttpGet]
        public IEnumerable<Patient> Get()
        {
            var result = db.Patients.Include(patients=>patients.problems).ToList();
            return (IEnumerable<Patient>)result;
        }
        [Authorize]
        // GET api/<PatientController>/5
        [HttpGet("{id}")]
        public Patient Get(int id)
        {
            var res = db.Patients
                .Where(a => a.Id == id).Include(a => a.problems ).FirstOrDefault();
            return res;
        }
        

        // POST api/<PatientController>
        //[Route("BookAppointment")]
        [HttpPost("{id}")]
        public IActionResult Post([FromBody] Patient patient, int id)
        {
            //db.Add(manager);
            //db.SaveChanges();
            Patient p1 = new Patient();
            p1.FirstName = patient.FirstName;
            p1.LastName = patient.LastName;
               p1.Address = patient.Address;
            p1.Age = patient.Age;
            p1.DoctorId = id;
            p1.Symptoms = patient.Symptoms;
            p1.PhoneNumber = patient.PhoneNumber;
            p1.Status = false;
            db.Add(p1);
            db.SaveChanges();
            return Ok(p1);

        }

        // PUT api/<PatientController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<PatientController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
