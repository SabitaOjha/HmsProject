﻿namespace Hms.Model
{
    public class Problems
    {
        public int Id { get; set; }
        public int PatientId { get; set; }
        public Patient patient;
         public string Problem { get; set; }
        public ICollection<Medicine> Medicines { get; set; }
        public Problems()
        {
            this.Medicines = new HashSet<Medicine>();
        }

    }
}
