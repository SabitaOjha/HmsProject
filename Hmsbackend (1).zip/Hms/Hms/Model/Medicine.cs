﻿namespace Hms.Model
{
    public class Medicine
    {
        public int Id { get; set; }
        public int ProblemId { get; set; }
        public Problems Problems;
        public string MedicineName { get; set; }
        public string Doases { get; set; }
        public string DoaseDescription { get; set; }
        public string Quantity { get; set; }
    }
}
