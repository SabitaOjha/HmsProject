﻿namespace Hms.Model
{
    public class Patient
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int DoctorId { get; set; }
        public  Doctor Doctor;
        public string Address { get; set; }
        public string Age { get; set; }
        public string Symptoms { get; set; }
        public string PhoneNumber { get; set; }
        public ICollection<Problems> problems { get; set; }
        public bool IsActive { get; set; }
        public bool Status { get; set; }
        public Patient()
        {
            this.problems = new HashSet<Problems>();
            this.IsActive = true;
            this.Status = true;
        }
      

   
    }
}
