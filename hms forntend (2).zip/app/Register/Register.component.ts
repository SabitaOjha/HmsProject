import { Component, OnInit } from '@angular/core';
import { ApiCallService } from '../api-call.service';
import { Register } from '../Model/Register';

@Component({
  selector: 'app-Register',
  templateUrl: './Register.component.html',
  styleUrls: ['./Register.component.css']
})
export class RegisterComponent{
  registerReq:Register = new Register();
  title = 'Hms';
  constructor(private apiservice:ApiCallService){}

  registerAdmin(){
    let adminData = this.registerReq.RegisterForm.value;
    this.apiservice.Register(adminData).subscribe(
            res=>{
              console.log(res);
            },
            err=>{
              console.log(err);

            }
    )
    }
}
