import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminDashboardComponent } from './AdminDashboard/AdminDashboard.component';
import { ManageDoctorComponent } from './ManageDoctor/ManageDoctor.component';



const routes: Routes = [
  
  {
    path:"AdminDashboard", component:AdminDashboardComponent
},
{
  path: "ManageDoctor", component:ManageDoctorComponent
}


];
 
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule{ }
