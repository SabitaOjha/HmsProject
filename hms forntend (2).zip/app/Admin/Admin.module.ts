import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminRoutingModule } from './Admin-routing.module';
import { AdminComponent } from './Admin.component';
import { AdminDashboardComponent } from './AdminDashboard/AdminDashboard.component';
import { ManageDoctorComponent } from './ManageDoctor/ManageDoctor.component';


@NgModule({
  declarations: [
    AdminDashboardComponent,
    ManageDoctorComponent
  
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AdminComponent]
})
export class AdminModule { }
