import { Component } from '@angular/core';
import { ApiCallService } from '../api-call.service';
import { Login } from '../Model/Login';

@Component({
  selector: 'app-Login',
  templateUrl: './Login.component.html'

})
export class LoginComponent {
  title = 'Hms';
  login:Login = new Login();
  constructor(private apiservice:ApiCallService){}
doLogin(){
    let loginData = this.login.LoginForm.value;
    this.apiservice.Login(loginData).subscribe(
        res=>{
            alert("You are logged in sucessfully");
        },
        err=>{
            console.log(err);
        }
    );
}
}
