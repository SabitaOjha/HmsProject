export class Problems{
    public Problem:string="";
}