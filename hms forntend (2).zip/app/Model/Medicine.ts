export class Medicine{
    public MedicineName:string = "";
    public Doases:string = "";
    public DoaseDescription:string = "";
    public Quantity:string = "";
}